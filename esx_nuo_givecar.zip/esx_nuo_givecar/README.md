
## Requirements
* [es_extended](https://github.com/ESX-Org/es_extended)


需要管理员权限才能使用
cn-zh
给自己
1./givecar [模组名]
给别人
2./giveyoucar [模组名] [游戏id(数字)]  
删除车辆
3./dvplate [车牌]


admin use
us-en
[give me]
1./givecar [model]
[give to Player]
2./giveyoucar [model] [Player game id (number)]
[Delete vehicle]
3./dvplate [plate]

