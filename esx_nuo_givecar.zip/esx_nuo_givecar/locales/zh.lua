Locales['zh'] = {

	['createPlate'] = '设置车牌',
	['errorPlate'] = '无效车牌',
	['dvPlate'] = '删除车牌:%s',
	['getCar'] = '您获得车牌:%s',
	['meAddCar'] = '您添加车牌:%s',
	
	

}
